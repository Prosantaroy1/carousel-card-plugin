<?php
if (! defined('ABSPATH')) {
	exit;
}

// Configuration should be loaded first.
require_once dirname(__FILE__) . '/config.php';
require_once FS_LITE_DIR . '/inc/Base/FS_Lite.php';
require_once FS_LITE_DIR . 'inc/Base/FSActivate.php';
